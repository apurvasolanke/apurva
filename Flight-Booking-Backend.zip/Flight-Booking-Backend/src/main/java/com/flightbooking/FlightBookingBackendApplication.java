package com.flightbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightBookingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightBookingBackendApplication.class, args);
	}

}
